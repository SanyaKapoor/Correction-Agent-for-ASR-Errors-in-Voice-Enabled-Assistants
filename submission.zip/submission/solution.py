class Agent(object):
    def __init__(self, phoneme_table, vocabulary) -> None:
        self.phoneme_table = phoneme_table
        self.vocabulary = vocabulary
        self.best_state = None
    def invert_phoneme_table(self, phoneme_table):
        inverted_phoneme_table = {}
        for key, values in phoneme_table.items():
            for value in values:
                inverted_phoneme_table[value] = key
        return inverted_phoneme_table
    def asr_corrector(self, environment):
        inverted_phoneme_table = self.invert_phoneme_table(self.phoneme_table)
        self.best_state = environment.init_state
        min_cost = environment.compute_cost(self.best_state)
        i = 0
        state_len = len(self.best_state)
        while i < state_len:
            char = self.best_state[i]
            two_char = ''.join(self.best_state[i:i+2])
            best_replacement = self.best_state
            best_replacement_cost = min_cost
            advance_index = 1
            if two_char in inverted_phoneme_table:
                replacement = inverted_phoneme_table[two_char]
                new_state = self.best_state[:i] + replacement + self.best_state[i+2:]
                new_cost = environment.compute_cost(new_state)
                if new_cost < best_replacement_cost:
                    best_replacement = new_state
                    best_replacement_cost = new_cost
                    advance_index = 2
            elif char in inverted_phoneme_table:
                replacement = inverted_phoneme_table[char]
                new_state = self.best_state[:i] + replacement + self.best_state[i+1:]
                new_cost = environment.compute_cost(new_state)
                if new_cost < best_replacement_cost:
                    best_replacement = new_state
                    best_replacement_cost = new_cost
                    advance_index = 1
            if best_replacement != self.best_state:
                self.best_state = best_replacement
                min_cost = best_replacement_cost
                state_len = len(self.best_state)
            i += advance_index
        for vocab_word in self.vocabulary:
            new_sentences = [
                f"{vocab_word} {self.best_state}",
                f"{self.best_state} {vocab_word}"
            ]
            for new_sentence in new_sentences:
                new_sentence = new_sentence.strip()
                cost = environment.compute_cost(new_sentence)
                if cost < min_cost:
                    min_cost = cost
                    self.best_state = new_sentence